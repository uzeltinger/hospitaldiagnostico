<?php

add_route_default('home', 'Home');
add_route('choose', 'Choose');
add_route('installations', 'Installations');
add_route('doctors', 'Doctors');
add_route('doctor', 'Doctor');
// add_route('test', 'Test');
